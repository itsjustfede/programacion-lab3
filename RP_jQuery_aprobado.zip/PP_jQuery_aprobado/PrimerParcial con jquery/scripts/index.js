var btnAlta;
var divFrm;
var frmAlta;
var divInfo;
var btnCancelar;

var lista;

window.onload = asignarEventos;

function asignarEventos() {

    $("#divFrm").hide();
    $("#divId").hide();
    
    //CLIC EN BOTON AGREGAR
    $("#btnAgregar").click(function(){
        mostrarFormulario();
    });
    //CLIC EN BOTON CANCELAR 
    $("#btnCancelar").click(function(){
        if(confirm("Desea cancelar?")){
            $("#divFrm").hide("slow");
            $("#divId").hide();
        }
    });

    //capturo el evento submit del form
    $("#formularioAgregar").submit(function(event){
        event.preventDefault();//mato el evento   

        if($(document.activeElement).val() == $("#btnDarDeAlta").val()){//pregunto cual boton envio el submit
            //CLIC EN BOTON DAR DE ALTA
            altaPersona();
            $("#divFrm").hide("slow");//oculto el form
        }
        else{
            //CLIC EN BOTON MODIFICAR 
            if (confirm("Esta seguro de que desea modificar a la persona de ID "+$("#txtId").val()+"?")) {
                modificacionPersona();
                $("#divFrm").hide("slow");//oculto el form
                $("#divId").hide();
            }  
        }      
    });

    //CLIC EN BOTON ELIMINAR
    $("#btnEliminar").click(function(){
        if (confirm("Esta seguro de que desea modificar al personaje de ID "+$("#txtId").val()+"?")) {
            eliminacionPersona();
            $("#divFrm").hide("slow");//oculto el form
            $("#divId").hide();
        }    
    });

    //################################################################

    setSpinner();

        //traer las personas y mostrar en la tabla
    traerPersonas();

}

function darAlta(e) {

    var data = e.target.parentElement.firstChild;
    var nombre = data.textContent;
    data = data.nextElementSibling;
    var apellido = data.textContent;
    data = data.nextElementSibling;
    var email = data.textContent;
    data = data.nextElementSibling;
    var gender = data.textContent;
    data = data.nextElementSibling;
    var id = data.textContent; 
    data = data.nextElementSibling;
    var active = data.textContent;
    data = data.nextElementSibling;
    var profesion = data.textContent;

    if(active == "true")
        active = true;
    else
        active = false;

    var persona = new Persona(nombre, apellido, email, gender, id, active, profesion);

    mostrarFormulario(persona);
    
    return persona;
}

function mostrarFormulario(persona) {
    $("#divFrm").show("slow");
    
    if (persona != undefined) {
        document.getElementById('txtId').value = persona.id;
        document.getElementById('txtNombre').value = persona.first_name;
        document.getElementById('txtApellido').value = persona.last_name;
        document.getElementById('txtEmail').value = persona.email;

        if(document.getElementsByName("sexo")[0].value == persona.gender){
            document.getElementsByName("sexo")[0].checked = true;
        }
        else{
            document.getElementsByName("sexo")[1].checked = true;
        }

        if(document.getElementById('slctProfesion')[0].textContent == persona.profesion){
            document.getElementById('slctProfesion')[0].selected = true;
        }
        else if(document.getElementById('slctProfesion')[1].textContent == persona.profesion){
            document.getElementById('slctProfesion')[1].selected = true;
        }
        else{
            document.getElementById('slctProfesion')[2].selected = true;
        }

        console.log(document.getElementById('slctProfesion').options);

        $("#divId").show();
        $("#btnEliminar").show();
        $("#btnModificar").show();
        $("#btnDarDeAlta").hide();
    } else {
        document.getElementById('txtNombre').value = "";
        document.getElementById('txtApellido').value = "";
        document.getElementById('txtEmail').value = "";

        $("#btnEliminar").hide();
        $("#btnModificar").hide();
        $("#btnDarDeAlta").show();
    }
}

function setSpinner(){
    $("#bodyTabla").empty();

    var div = document.getElementById('divSpinner');
    
    var imagen = document.createElement('img');
    
    imagen.setAttribute('src','./images/loading.gif');
    imagen.setAttribute('style','align:middle');

    div.appendChild(imagen);
}
function actualizarTabla(lista) {

        $("#bodyTabla").empty();
        $("#divSpinner").empty();

        var tabla = document.createElement('tbody');
    
        tabla.setAttribute('id', 'text-align:center');
    
        for(var i in lista){
            var fila = document.createElement('tr');
            for (var j in lista[i]){
                var celda = document.createElement('td');

                celda.addEventListener('click', darAlta);

                celda.setAttribute('style', 'text-align:center');
               
                var dato = document.createTextNode(lista[i][j]);
                celda.appendChild(dato);
                fila.appendChild(celda);
            }    
            document.getElementById('bodyTabla').appendChild(fila);        
        }
}


function altaPersona() {
    //agregar el codigo que crea conveniente
  
    setSpinner();
    var persona;
    persona = crearPersona(true);
    guardarPersona(persona);

     //enviar la insercion al server
}


function eliminacionPersona() {
    setSpinner();
    var persona;
    persona = crearPersona(false);
    eliminarPersona(persona);

}

function modificacionPersona() {
    //agregar el codigo que crea conveniente
    var gender;
    if (document.getElementById('rdoMasculino').checked) {
        gender = document.getElementById('rdoMasculino').value;
    }
    else {
        gender = document.getElementById('rdoFemenino').value;
    }
    var persona;
    persona = crearPersona(true);
    persona.gender = gender;
    modificarPersona(persona);

    //enviar la modificacion al server


}

function Persona(nombre,apellido,email,sexo,id,active,profesion){
    this.first_name = nombre;
    this.last_name = apellido;
    this.email = email;
    this.gender = sexo;
    this.id = id;
    this.active = active;
    this.profesion = profesion;
}

function crearPersona(active){
    var nombre = document.getElementById('txtNombre').value;
    var apellido = document.getElementById('txtApellido').value;
    var email = document.getElementById('txtEmail').value;
    var gender = document.getElementsByName("sexo");
    var id = 0;

    if (document.getElementById("txtId").value != ""){
        id = parseInt(document.getElementById('txtId').value);
    }

    for(i=0;i<gender.length;i++) 
    if (gender[i].checked) { 
        gender = gender[i].value; 
        break; 
    } 

    var profesion = document.getElementById("slctProfesion").selectedOptions[0].textContent;

    var persona = new Persona(nombre, apellido, email, gender, id, active, profesion);
    
    return persona;
}




