$(function () {
    cargarSexo();
    calcularPromedio();
    calcularGenderMix();
    $('#cmbFiltro').change(function () {
        filtrarPersonas(this.value);
        calcularPromedio();
        calcularGenderMix();
    });
    //agregar al evento change de los 4 checkbox, el manejador "mapearCampos"
    $("#chkId").change(function () {
        alert("fede");
    });
});
function cargarSexo() {
    var todos = document.createElement("option");
    var diputado = document.createElement("option");
    var senador = document.createElement("option");
    todos.appendChild(document.createTextNode("Todos"));
    diputado.appendChild(document.createTextNode("Diputado"));
    senador.appendChild(document.createTextNode("Senador"));
    document.getElementById("cmbFiltro").appendChild(todos);
    document.getElementById("cmbFiltro").appendChild(diputado);
    document.getElementById("cmbFiltro").appendChild(senador);
}
function filtrarPersonas(tipo) {
    var personasFiltradas;
    if (lista != undefined) {
        if (tipo != "Todos") {
            personasFiltradas = lista
                .filter(function (persona) {
                return persona.cargo === tipo;
            });
            actualizarTabla(personasFiltradas);
        }
        else {
            actualizarTabla(lista);
        }
    }
}
function calcularPromedio() {
    var promedio = 0;
    var cantidadTotal;
    if (lista != undefined) {
        cantidadTotal = lista.filter(function (persona) {
            if ($("#cmbFiltro").val() === "Todos")
                return persona;
            else
                return persona.cargo === $("#cmbFiltro").val();
        });
        promedio = lista.filter(function (persona) {
            if ($("#cmbFiltro").val() === "Todos")
                return persona.cargo;
            else
                return persona.cargo === $("#cmbFiltro").val();
        })
            .map(function (users) {
            return parseInt(users.edad);
        })
            .reduce(function (previo, actual) {
            return previo + actual;
        }, 0) / cantidadTotal.length;
    }
    $("#txtPromedio").val(promedio);
}
function calcularGenderMix() {
    var porcentaje = 0;
    var cantidadTotalMasculino;
    var cantidadSeleccionado;
    if (lista != undefined) {
        cantidadSeleccionado = lista.filter(function (persona) {
            if ($("#cmbFiltro").val() === "Todos")
                return persona;
            else
                return persona.cargo === $("#cmbFiltro").val();
        });
        cantidadTotalMasculino = lista.filter(function (persona) {
            if ($("#cmbFiltro").val() === "Todos")
                return persona;
            else
                return persona.cargo === $("#cmbFiltro").val();
        }).filter(function (persona) {
            if (persona.gender === "Masculino")
                return persona;
        });
        porcentaje = (cantidadTotalMasculino.length * 100) / cantidadSeleccionado.length;
        ;
    }
    $("#txtGenderMix").val(porcentaje);
}
function mapearCampos(lista) {
    var chkName = $('#chkName')[0].checked;
    var chkApellido = $('#chkApellido')[0].checked;
    var chkEdad = $('#chkEdad')[0].checked;
    var chkEmail = $('#chkEmail')[0].checked;
    var chkGender = $('#chkGender')[0].checked;
    var chkId = $('#chkId')[0].checked;
    var chkActive = $('#chkActive')[0].checked;
    var chkProfesion = $('#chkProfesion')[0].checked;
    var array = [chkName, chkApellido, chkEdad, chkEmail, chkGender, chkId, chkActive, chkProfesion];
    for (var item in array) {
        if (item) {
        }
    }
}
