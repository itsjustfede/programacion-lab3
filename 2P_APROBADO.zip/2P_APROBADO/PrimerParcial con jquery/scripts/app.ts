$(function () {
    
        cargarSexo();
        calcularPromedio();
        calcularGenderMix();
    
    
        $('#cmbFiltro').change(function () {
            filtrarPersonas(this.value);
            calcularPromedio();
            calcularGenderMix();
        });
    
        //agregar al evento change de los 4 checkbox, el manejador "mapearCampos"
    
        $("#chkId").change(function() {
                alert("fede"); 
        });
    
    });
    
    function cargarSexo() {
      
       let todos = document.createElement("option");
       let diputado = document.createElement("option");
       let senador = document.createElement("option");
    
       todos.appendChild(document.createTextNode("Todos"));
       diputado.appendChild(document.createTextNode("Diputado"));
       senador.appendChild(document.createTextNode("Senador"));
    
       document.getElementById("cmbFiltro").appendChild(todos);
       document.getElementById("cmbFiltro").appendChild(diputado);
       document.getElementById("cmbFiltro").appendChild(senador);
       
    
    }
    
    function filtrarPersonas(tipo:string) {
    
        let personasFiltradas: Array<Clases.Persona>;
        if (lista != undefined){
            if(tipo != "Todos"){
                personasFiltradas = lista
                .filter(function(persona){
                    return persona.cargo === tipo;
                });
                actualizarTabla(personasFiltradas);
            }
            else{
                actualizarTabla(lista);
            }
        }    
    }
    
    function calcularPromedio() {
    
        let promedio:number = 0;
        let cantidadTotal;
    
        if (lista != undefined){

            cantidadTotal = lista.filter(function(persona){
                if($("#cmbFiltro").val() === "Todos")
                    return persona;
                else
                    return persona.cargo === $("#cmbFiltro").val();
                    
            });

            promedio = lista.filter(function(persona){
                if($("#cmbFiltro").val() === "Todos")
                    return persona.cargo;
                else
                    return persona.cargo === $("#cmbFiltro").val();
                    
            })
            .map(function(users){
                return parseInt(users.edad)
            })
            .reduce(function(previo, actual) {
            return previo + actual;
            }, 0) / cantidadTotal.length;
        }
        
        $("#txtPromedio").val(promedio);
    }

    function calcularGenderMix() {
        
            let porcentaje:number = 0;
            let cantidadTotalMasculino;
            let cantidadSeleccionado:number;
        
            if (lista != undefined){

                cantidadSeleccionado = lista.filter(function(persona){
                    if($("#cmbFiltro").val() === "Todos")
                        return persona;
                    else
                        return persona.cargo === $("#cmbFiltro").val();
                        
                });
                
                cantidadTotalMasculino = lista.filter(function(persona){
                    if($("#cmbFiltro").val() === "Todos")
                        return persona;
                    else
                        return persona.cargo === $("#cmbFiltro").val();
                        
                }).filter(function(persona){
                    if(persona.gender === "Masculino")
                        return persona;                        
                });

                porcentaje = (cantidadTotalMasculino.length * 100) / cantidadSeleccionado.length);
            }
            
            $("#txtGenderMix").val(porcentaje);
        }
    
    function mapearCampos(lista:Array<Clases.Persona>) {
    
        let chkName: boolean = (<HTMLInputElement> $('#chkName')[0]).checked;
        let chkApellido: boolean = (<HTMLInputElement> $('#chkApellido')[0]).checked;
        let chkEdad: boolean = (<HTMLInputElement> $('#chkEdad')[0]).checked;
        let chkEmail: boolean = (<HTMLInputElement> $('#chkEmail')[0]).checked;
        let chkGender: boolean = (<HTMLInputElement> $('#chkGender')[0]).checked;
        let chkId: boolean = (<HTMLInputElement> $('#chkId')[0]).checked;
        let chkActive: boolean = (<HTMLInputElement> $('#chkActive')[0]).checked;
        let chkProfesion: boolean = (<HTMLInputElement> $('#chkProfesion')[0]).checked;
              
        let array:boolean[] = [chkName,chkApellido,chkEdad,chkEmail,chkGender,chkId,chkActive,chkProfesion];
    
        for (const item in array) {
            if (item){                                
            }
        }
    }