//realizar codigo de la clase "Heroe". el metodo toJSON es parte de la clase y es provisto en el starter


namespace Clases{

    export class Persona{
        public first_name:string;
        public last_name:string;
        public edad:number;
        public email:string;
        public gender:string;
        public id:number;
        public active:boolean;
        public cargo:string;
       
        constructor(nombre:string, apellido:string, edad:number, email:string, gender:string){
            this.first_name = nombre;
            this.email = email;
            this.last_name = apellido;
            this.edad = edad;
            this.gender = gender;
        }
    
        public toJSON():string{
            let json: string = `{"first_name":"${this.first_name}", "last_name":"${this.last_name}", "edad":"${this.edad}", "email":"${this.email}", "gender":"${this.gender}", "id":${this.id}, "active":"${this.active}", "cargo":"${this.cargo}"}`;
            return json;
        }
    
    }

    export class Legislador extends Persona{
        public id:number;
        
        public active:boolean;
        public cargo:string;
       
    
        constructor(nombre:string, apellido:string, edad:number, email:string, gender:string, id:number, active:boolean, cargo:string){
            super(nombre, apellido, edad, email, gender);
            this.id = id;
            this.active = active;
            this.cargo = cargo;
        }
        

        public toJSON():string{

            let cad:string = super.toJSON().replace('}', '');          
            

            let json:string = cad + `, "id":${this.id}, "active":"${this.active}", "cargo":"${this.cargo}"}`;
            return json;
        }
    
    }

    export enum tipoCargo{
        Diputado,
        Senador
    }

}