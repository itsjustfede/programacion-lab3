$(document).ready(function() {
    //traer();
    ejecutarTransaccion("actualizarLista");
    
    $("#divFormAgregar").hide();

    //CLIC EN BOTON AGREGAR
    $("#btnAgregar").click(function(){
        ejecutarTransaccion("Mostrar");
    });
    //CLIC EN BOTON CANCELAR 
    $("#btnCancelar").click(function(){
        if(confirm("Desea cancelar?")){
            $("#divFormAgregar").hide("slow");
        }
    });

    //capturo el evento submit del form
    $("#formularioAgregar").submit(function(event){
        event.preventDefault();//mato el evento   

        if($(document.activeElement).val() == $("#btnDarDeAlta").val()){//pregunto cual boton envio el submit
            //CLIC EN BOTON DAR DE ALTA
            ejecutarTransaccion("Alta");
            $("#divFormAgregar").hide("slow");//oculto el form
        }
        else{
            //CLIC EN BOTON MODIFICAR 
            if (confirm("Esta seguro de que desea modificar al personaje de ID "+$("#txtId").val()+"?")) {
                ejecutarTransaccion("Modificacion");
                $("#divFormAgregar").hide("slow");//oculto el form
            }  
        }      
    });

    //CLIC EN BOTON ELIMINAR
    $("#btnEliminar").click(function(){
        if (confirm("Esta seguro de que desea modificar al personaje de ID "+$("#txtId").val()+"?")) {
            ejecutarTransaccion("Baja");
            $("#divFormAgregar").hide("slow");//oculto el form
        }    
    });
});

function Heroe(id, nombre, apellido, alias, edad, lado) {
    this.id = id;
    this.nombre = nombre;
    this.apellido = apellido;
    this.alias = alias;
    this.edad = edad;
    this.lado = lado;
}

function crearHeroe() {
    var txtId = document.getElementById("txtId").value;
    var txtNombre = document.getElementById("txtNombre").value;
    var txtApellido = document.getElementById("txtApellido").value;
    var txtAlias = document.getElementById("txtAlias").value;
    var txtEdad = document.getElementById("txtEdad").value;
    var rdLado = document.getElementsByName("lado");

    for(i=0;i<rdLado.length;i++) 
        if (rdLado[i].checked) { 
            rdLado = rdLado[i].value; 
            break; 
        } 

    var heroe = new Heroe(txtId, txtNombre, txtApellido, txtAlias, txtEdad, rdLado);

    return heroe;
}

function mostrarPreloader() {
    $("#divTablaPersonajes").html('<img src="./images/preloader.gif">');
}

function agregarManejadoresTd() {
    for(var i=0; i < document.getElementsByTagName('td').length; i++){        
        document.getElementsByTagName('td')[i].addEventListener('click', traerDatosTd);
    }
}

function traerDatosTd(e){
    // var heroe = new Heroe();

    // var data = e.parentElement.firstChild;    
    // heroe.id = data.textContent;
    
    // data = data.nextSibling;
    // heroe.nombre = data.textContent;

    // data = data.nextSibling;
    // heroe.apellido = data.textContent;

    // data = data.nextSibling;
    // heroe.alias = data.textContent;

    // data = data.nextSibling;
    // heroe.edad = data.textContent;

    // data = data.nextSibling;
    // heroe.lado = data.textContent;

    var data = e.target.parentElement.firstChild;
    var id = data.textContent;
    data = data.nextElementSibling;
    var nombre = data.textContent;
    data = data.nextElementSibling;
    var apellido = data.textContent;
    data = data.nextElementSibling;
    var alias = data.textContent;
    data = data.nextElementSibling;
    var edad = data.textContent;
    data = data.nextElementSibling;
    var lado = data.textContent;

    var heroe = new Heroe(id, nombre, apellido, alias, edad, lado);
    console.log(heroe);
    
    ejecutarTransaccion("MostrarHeroe", heroe);
}

function altaPersonaje() {
    var heroe;
    heroe = crearHeroe();
    ejecutarTransaccion("Insertar", heroe);
}

function eliminarPersonaje() {
    var heroe;
    heroe = crearHeroe();
    ejecutarTransaccion("Eliminar", heroe);
}

function modificarPersonaje() {
    var heroe;
    heroe = crearHeroe();
    ejecutarTransaccion("Modificar", heroe);
}