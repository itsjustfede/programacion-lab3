function mostrarFormulario(heroe) {
    if (heroe != undefined) {
        $("#divFormAgregar").show("slow");

        $("#txtId").attr("readOnly","readOnly");
        $("#txtId").val(heroe.id);
        $("#txtNombre").val(heroe.nombre);
        $("#txtApellido").val(heroe.apellido);
        $("#txtAlias").val(heroe.alias);
        $("#txtEdad").val(heroe.edad);

        if(document.getElementsByName("lado")[0].value == heroe.lado){
            document.getElementsByName("lado")[0].checked = true;
        }
        else{
            document.getElementsByName("lado")[1].checked = true;
        }

        $("#btnEliminar").show();
        $("#btnModificar").show();
        $("#btnDarDeAlta").hide();
    } else {
        $("#divFormAgregar").show("slow");

        limpiarInputs();
        
        $("#btnEliminar").hide();
        $("#btnModificar").hide();
        $("#btnDarDeAlta").show();
    }
}

function limpiarInputs() {
    $("#txtId").removeAttr("readOnly");
    $("#txtId").val("");
    $("#txtNombre").val("");
    $("#txtApellido").val("");
    $("#txtAlias").val("");
    $("#txtEdad").val("");
    document.getElementsByName("lado")[0].checked = true;
}

function actualizarTabla(lista){
    if(lista.length > 0){

        var tabla = "<table><thead><tr><th>Id</th><th>Nombre</th><th>Apellido</th>" +
                    "<th>Alias</th><th>Edad</th><th>Lado</th></tr>";
        for(var i = 0; i < lista.length; i++){
            tabla += "<tr><td>" + lista[i].id + "</td><td>" + lista[i].nombre + "</td>"+
            "<td>" + lista[i].apellido + "</td><td>" + lista[i].alias + "</td>" +
            "<td>" + lista[i].edad + "</td><td>" + lista[i].lado + "</td></tr>";
        }

        tabla += "</table>";

        $("#divTablaPersonajes").hide();//oculto el div 
        document.getElementById('divTablaPersonajes').innerHTML = "";
        document.getElementById('divTablaPersonajes').innerHTML = tabla;
        $("#divTablaPersonajes").show("slow");//muestro el div con animacion

        agregarManejadoresTd();
    }
}