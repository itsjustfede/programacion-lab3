function insertarHeroe(heroe) {
    var data = {"collection":"heroes",
                    "heroe":heroe};
    xhr = new XMLHttpRequest();

    xhr.onreadystatechange = function(){
        if(this.readyState == 4){
            if(this.status == 200){
                $("#divFormAgregar").hide("slow");
                traer();
            }
        }
    };

    xhr.open("POST", "/agregar", true);
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.send(JSON.stringify(data));
}

function eliminarHeroe(heroe) {
    xhr = new XMLHttpRequest();
    var data = {
        "collection":"heroes",
        "id":heroe.id
    }
    xhr.onreadystatechange = function(){
        if (xhr.readyState == 4) {
            if (xhr.status == 200) {
                $("#divFormAgregar").hide("slow");
                traer();
            }
        }
    };
    xhr.open("POST", "/eliminar", true)
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.send(JSON.stringify(data));
    console.log(data);
}

function modificarHeroe(heroe) {
    var data = {
        "collection":"heroes",
        "heroe": heroe
    }

    $.ajax({
        type: 'POST',
        async: true,
        url: "/modificar",
        dataType : "json",
        contentType: "application/json",
        data: JSON.stringify(data),   
        beforeSend: function(){
            mostrarPreloader();
        },
        success: function(result) {
            $("#divFormAgregar").hide("slow");
            traer();
            alert(result.message);
        },
        error: function (xhr, status) {
            alert("Error " + xhr.status + " " + xhr.statusText);
        }
    });
}
