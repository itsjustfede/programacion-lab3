///<reference path="./heroe.ts"/>

namespace Clases{

 
}