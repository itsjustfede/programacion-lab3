//CONTROLADORES DE EVENTOS###################

$(document).ready(function() {
    //traer();
    ejecutarTransaccion("actualizarLista");
    
    $("#divFormAgregar").hide();

    //CLIC EN BOTON AGREGAR
    $("#btnAgregar").click(function(){
        ejecutarTransaccion("Mostrar");
    });

    $("#btnLimpiar").click(function(){
        cleanStorage();
    });

    //CLIC EN BOTON CANCELAR 
    $("#btnCancelar").click(function(){
        if(confirm("Desea cancelar?")){
            $("#divFormAgregar").hide("slow");
        }
    });

    //capturo el evento submit del form
    $("#formularioAgregar").submit(function(event){
        event.preventDefault();//mato el evento   

        if($(document.activeElement).val() == $("#btnDarDeAlta").val()){//pregunto cual boton envio el submit
            //CLIC EN BOTON DAR DE ALTA
            ejecutarTransaccion("Alta");
            $("#divFormAgregar").hide("slow");//oculto el form
        }
        else{
            //CLIC EN BOTON MODIFICAR 
            if (confirm("Esta seguro de que desea modificar al personaje de ID "+$("#txtId").val()+"?")) {
                ejecutarTransaccion("Modificacion");
                $("#divFormAgregar").hide("slow");//oculto el form
            }  
        }      
    });

    //CLIC EN BOTON ELIMINAR
    $("#btnEliminar").click(function(){
        if (confirm("Esta seguro de que desea modificar al personaje de ID "+$("#txtId").val()+"?")) {
            ejecutarTransaccion("Baja");
            $("#divFormAgregar").hide("slow");//oculto el form
        }    
    });
});

/*###################################*/


function mostrarFormulario(heroe) {
    if (heroe != undefined) {
        $("#divFormAgregar").show("slow");

        $("#txtId").attr("readOnly","readOnly");
        $("#txtId").val(heroe.id);
        $("#txtNombre").val(heroe.nombre);
        $("#txtApellido").val(heroe.apellido);
        $("#txtAlias").val(heroe.alias);
        $("#txtEdad").val(heroe.edad);
        $("#slctEditorial").val(heroe.editorial);

        if(document.getElementsByName("lado")[0].value == heroe.lado){
            document.getElementsByName("lado")[0].checked = true;
        }
        else{
            document.getElementsByName("lado")[1].checked = true;
        }

        $("#btnEliminar").show();
        $("#btnModificar").show();
        $("#btnDarDeAlta").hide();
    } else {
        $("#divFormAgregar").show("slow");

        limpiarInputs();
        
        $("#btnEliminar").hide();
        $("#btnModificar").hide();
        $("#btnDarDeAlta").show();
    }
}

function limpiarInputs() {
    $("#txtId").removeAttr("readOnly");
    $("#txtId").val("");
    $("#txtNombre").val("");
    $("#txtApellido").val("");
    $("#txtAlias").val("");
    $("#txtEdad").val("");
    document.getElementsByName("lado")[0].checked = true;
}

function actualizarTabla(lista){
    if(lista.length > 0){
        var tabla = "<table><thead><tr><th>Id</th><th>Nombre</th><th>Apellido</th>" +
                    "<th>Alias</th><th>Edad</th><th>Lado</th><th>Editorial</th></thead></tr>";
        for(var i = 0; i < lista.length; i++){

            if(lista[i].editorial == undefined){
                lista[i].editorial = "No definido";
            }

            tabla += "<tr><td>" + lista[i].id + "</td><td>" + lista[i].nombre + "</td>"+
            "<td>" + lista[i].apellido + "</td><td>" + lista[i].alias + "</td>" +
            "<td>" + lista[i].edad + "</td><td>" + lista[i].lado + "</td><td>" + lista[i].editorial + "</td></tr>";
        }
    }
    else{
        var tabla = "<table><thead>No hay elementos para mostrar</thead></tr>";
    }

    tabla += "</table>";

    $("#divTablaPersonajes").hide();//oculto el div 
    document.getElementById('divTablaPersonajes').innerHTML = "";
    document.getElementById('divTablaPersonajes').innerHTML = tabla;
    $("#divTablaPersonajes").show("slow");//muestro el div con animacion

    agregarManejadoresTd();
}