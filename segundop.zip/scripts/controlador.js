function ejecutarTransaccion(transaccion, heroe) {

    switch (transaccion) {

        case "Mostrar":

            mostrarFormulario();//vista           
            break;

        case "MostrarHeroe":

            mostrarFormulario(heroe);//vista
            break;

        case "Alta":

            altaPersonaje();//modelo
            break;

        case "Baja":

            eliminarPersonaje();//modelo
            break;

        case "Modificacion":

            modificarPersonaje();//modelo
            break;

        case "Insertar":

            insertarHeroe(heroe);//despachador
            break;

        case "Eliminar":

            eliminarHeroe(heroe);//despachador
            break;

        case "Modificar":

            modificarHeroe(heroe);//despachador
            break;

        case "actualizarLista":

            traerListaHeroes(manejarActualizarLista);//modelo
            break;
    }

}

function manejarActualizarLista(l){
    lista = l;
    actualizarTabla(lista);
}


