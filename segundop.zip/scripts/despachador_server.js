const server_url = "http://localhost:3000/";
var xhr;
var lista;

function traerListaHeroes(e){
    xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function(){
        if (xhr.readyState == 4) {
            if (xhr.status == 200) {
                lista = JSON.parse(xhr.responseText).data;
                e(lista);
            }
        }
    };
    xhr.open("GET", "/traer?collection=heroes", true)
    xhr.send();

    return lista;
}

function insertarHeroe(heroe) {
    mostrarPreloader();
    var data = {"collection":"heroes",
                    "heroe":heroe};
    xhr = new XMLHttpRequest();

    xhr.onreadystatechange = function(){
        if(this.readyState == 4){
            if(this.status == 200){
                ejecutarTransaccion("actualizarLista");
            }
        }
    };

    xhr.open("POST", "/agregar", true);
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.send(JSON.stringify(data));
}

function eliminarHeroe(heroe) {
    mostrarPreloader();
    xhr = new XMLHttpRequest();
    var data = {
        "collection":"heroes",
        "id":heroe.id
    }
    xhr.onreadystatechange = function(){
        if (xhr.readyState == 4) {
            if (xhr.status == 200) {
                ejecutarTransaccion("actualizarLista");
            }
        }
    };
    xhr.open("POST", "/eliminar", true)
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.send(JSON.stringify(data));
}

function modificarHeroe(heroe) {
    var data = {
        "collection":"heroes",
        "heroe": heroe
    }

    $.ajax({
        type: 'POST',
        async: true,
        url: "/modificar",
        dataType : "json",
        contentType: "application/json",
        data: JSON.stringify(data),   
        beforeSend: function(){
            mostrarPreloader();
        },
        success: function(result) {
            ejecutarTransaccion("actualizarLista");
            alert(result.message);
        },
        error: function (xhr, status) {
            alert("Error " + xhr.status + " " + xhr.statusText);
        }
    });
}