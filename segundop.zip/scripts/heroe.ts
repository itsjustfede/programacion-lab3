//realizar codigo de la clase "Heroe". el metodo toJSON es parte de la clase y es provisto en el starter
///<reference path="./enumerados.ts"/>
///<reference path="./personaje.ts"/>

namespace Clases{

    export abstract class Personaje{
        public nombre:string;
        public apellido:string;
        public edad:number;
       
        constructor(nombre:string, apellido:string, edad:number){
            this.nombre = nombre;
            this.edad = edad;
            this.apellido = apellido;
        }
    
        public toJSON():string{
            let json: string = `{"nombre":"${this.nombre}", "apellido":"${this.apellido}", "edad":${this.edad}}`;
            return json;
        }
    
    }

    export class Heroe extends Personaje{
        public id:number;
        public lado:tipoLado;
        public alias:string;
        public editorial:string;
       
    
        constructor(nombre:string, apellido:string, edad:number, id:number, alias:string, lado:tipoLado, editorial:string){
            super(nombre, apellido, edad);
            this.id = id;
            this.lado = lado;
            this.alias = alias;
            this.editorial = editorial;
        }
        

        public toJSON():string{

            let cad:string = super.toJSON().replace('}', '');          
            

            let json:string = cad + `, "id":${this.id}, "lado":${this.lado.toString()}, "alias":"${this.alias}", "editorial":"${this.editorial}"}`;
            return json;
        }
    
    }
}