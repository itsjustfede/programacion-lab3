
// function Heroe(id, nombre, apellido, alias, edad, lado, editorial) {
//     this.id = id;
//     this.nombre = nombre;
//     this.apellido = apellido;
//     this.alias = alias;
//     this.edad = edad;
//     this.lado = lado;
//     this.editorial = editorial;
// }

function cleanStorage() {
    localStorage.clear();
    alert("LocalStorage Limpio");
}

function crearHeroe() {
    var txtId = document.getElementById("txtId").value;
    var txtNombre = document.getElementById("txtNombre").value;
    var txtApellido = document.getElementById("txtApellido").value;
    var txtAlias = document.getElementById("txtAlias").value;
    var txtEdad = document.getElementById("txtEdad").value;
    var rdLado = document.getElementsByName("lado");
    var slctEditorial = document.getElementById("slctEditorial").value;

    for(i=0;i<rdLado.length;i++) 
        if (rdLado[i].checked) { 
            rdLado = rdLado[i].value; 
            break; 
        } 

    // var heroe = new Clases.Heroe(txtId, txtNombre, txtApellido, txtAlias, txtEdad, rdLado, slctEditorial);
    var heroe = new Clases.Heroe(txtNombre, txtApellido, txtEdad, txtId, txtAlias, rdLado, slctEditorial);
    return heroe;
}

function mostrarPreloader() {
    $("#divTablaPersonajes").html('<img src="./images/preloader.gif">');
}

function agregarManejadoresTd() {
    for(var i=0; i < document.getElementsByTagName('td').length; i++){        
        document.getElementsByTagName('td')[i].addEventListener('click', traerDatosTd);
    }
}

function traerDatosTd(e){
    // var heroe = new Heroe();

    // var data = e.parentElement.firstChild;    
    // heroe.id = data.textContent;
    
    // data = data.nextSibling;
    // heroe.nombre = data.textContent;

    // data = data.nextSibling;
    // heroe.apellido = data.textContent;

    // data = data.nextSibling;
    // heroe.alias = data.textContent;

    // data = data.nextSibling;
    // heroe.edad = data.textContent;

    // data = data.nextSibling;
    // heroe.lado = data.textContent;

    var data = e.target.parentElement.firstChild;
    var id = data.textContent;
    data = data.nextElementSibling;
    var nombre = data.textContent;
    data = data.nextElementSibling;
    var apellido = data.textContent;
    data = data.nextElementSibling;
    var alias = data.textContent;
    data = data.nextElementSibling;
    var edad = data.textContent;
    data = data.nextElementSibling;
    var lado = data.textContent;
    data = data.nextElementSibling;
    var editorial = data.textContent;
    
    //Clases.Heroe(nombre, apellido, edad, id, alias, lado, editorial);
    var heroe = new Clases.Heroe(nombre, apellido, edad, id, alias, lado, editorial);
    console.log(e);
    
    ejecutarTransaccion("MostrarHeroe", heroe);
}

function altaPersonaje() {
    var heroe;
    heroe = crearHeroe();
    ejecutarTransaccion("Insertar", heroe);
}

function eliminarPersonaje() {
    var heroe;
    heroe = crearHeroe();
    ejecutarTransaccion("Eliminar", heroe);
}

function modificarPersonaje() {
    var heroe;
    heroe = crearHeroe();
    ejecutarTransaccion("Modificar", heroe);
}