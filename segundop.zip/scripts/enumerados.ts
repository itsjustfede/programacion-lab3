namespace Clases{

    export enum tipoLado{
         Heroe,
         Villano
     }
 
 }