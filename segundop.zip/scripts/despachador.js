function traerListaHeroes(e){
    var heroesString = localStorage.getItem("Heroes");
    var heroes = JSON.parse(heroesString);
    console.log(heroes);
    if(heroes != null){
        e(heroes);        
    }
}

function insertarHeroe(heroe) {
    var heroesString = localStorage.getItem("Heroes");
    var heroesJson = JSON.parse(heroesString);

    if(heroesJson == null){
        array = [JSON.parse(heroe.toJSON())];
        localStorage.setItem("Heroes", JSON.stringify(array));
    }
    else{
        heroesJson.push(JSON.parse(heroe.toJSON()));
        localStorage.setItem("Heroes", JSON.stringify(heroesJson));
    }
    
    ejecutarTransaccion("actualizarLista");
}

function eliminarHeroe(heroe) {
    var heroesString = localStorage.getItem("Heroes");
    var heroesJson = JSON.parse(heroesString);
    
    for (var i = 0; i < heroesJson.length; i++) {
        if(heroesJson[i].id == heroe.id){
            heroesJson.splice(i,1);
            localStorage.setItem("Heroes", JSON.stringify(heroesJson));
            break;
        }       
    }

    ejecutarTransaccion("actualizarLista");
}

function modificarHeroe(heroe) {
    var heroesString = localStorage.getItem("Heroes");
    var heroesJson = JSON.parse(heroesString);
    
    for (var i = 0; i < heroesJson.length; i++) {
        if(heroesJson[i].id == heroe.id){
            heroesJson[i].nombre = heroe.nombre;
            heroesJson[i].apellido = heroe.apellido;
            heroesJson[i].edad = heroe.edad;
            heroesJson[i].alias = heroe.alias;
            heroesJson[i].lado = heroe.lado;
            heroesJson[i].editorial = heroe.editorial;

            localStorage.setItem("Heroes", JSON.stringify(heroesJson));
            break;
        }       
    }

    ejecutarTransaccion("actualizarLista");
}