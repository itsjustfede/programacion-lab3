<?php 

class pedido_producto 
{
	public $id_pedido;
	public $id_producto;
	public $cantidad;
	public $estado; //1 si esta tomado por un empleado/ 0 si nadie lo tomo todavia/ 2 producto listo para servir

	public static function traerPedidosProductos()
	{
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta = $objetoAccesoDato->RetornarConsulta("select * from pedidos_productos");
		$consulta->execute();			
		return $consulta->fetchAll(PDO::FETCH_CLASS, "pedido_producto");
	}

	public static function traerUnPedidoProductos($id)
	{
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta = $objetoAccesoDato->RetornarConsulta("select * from pedidos_productos WHERE id_pedido = '$id'");
		$consulta->execute();			
		return $consulta->fetchAll(PDO::FETCH_CLASS, "pedido_producto");
	}

	public static function InsertarPedidoProducto($id_pedido, $producto)
	{
		if(isset($id_pedido) != null && isset($producto) != null)
		{
			$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
	        $consulta =$objetoAccesoDato->RetornarConsulta("
	        	INSERT into pedidos_productos (id_pedido, id_producto, cantidad, estado) VALUES('$id_pedido','$producto->id', '$producto->cantidad', 0)");
			$consulta->execute();	               
			//return $objetoAccesoDato->RetornarUltimoIdInsertado();
			return true;
		}
		else
		{
			$nueva = new stdclass();
        	$nueva->respuesta = "Parametros faltantes";
        	$newResponse = json_encode($nueva, 200);
        	return $newResponse;
		}
	}

	public static function ModificarPedidoProducto($id_pedido, $id_producto, $estado, $tiempo, $demora)
	{
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("
			UPDATE pedidos_productos 
			SET estado = '$estado',
			tiempo_preparacion = '$tiempo',
			demora_empleado = '$demora'
			WHERE id_pedido = '$id_pedido' AND id_producto = '$id_producto'");
		return $consulta->execute();
	}

	public static function ModificarPedidoProductoEstado($id_pedido, $id_producto, $estado)
	{
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("
			UPDATE pedidos_productos 
			set estado = '$estado'
			WHERE id_pedido = '$id_pedido' AND id_producto = '$id_producto'");
		return $consulta->execute();
	}

}



?>