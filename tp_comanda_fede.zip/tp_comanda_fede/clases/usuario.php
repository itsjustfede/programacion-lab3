<?php 
include_once 'usuarioPDO.php';
class Usuario
{
	public $id;
	public $nombre;
	public $tipo;
	public $clave;
	public $estado; //activo/suspendido -> 1/0

	public function __construct($nom = null, $pass = null, $type = null, $estado = null)
	{
		if(func_num_args() != 0)
		{
			$this->nombre = $nom;
			$this->tipo = $type;
			$this->clave = $pass;
			$this->estado = $estado;
		}
	}

	public static function verificarCrearToken($ArrayDeParametros)
	{
		$datos = array('nombre' => $ArrayDeParametros['nombre'], 'clave' => $ArrayDeParametros['clave']);
        $employee = new Usuario($datos['nombre'], $datos['clave']);
        $response = $employee->VerificarUsuario(); 
        if($response == false)
        {
        	$nueva = new stdclass();
        	$nueva->respuesta = "El usuario no existe.";
        	$newResponse = json_encode($nueva, 200);
        }
        else
        {  
          	$token = AutentificadorJWT::CrearToken($response); 
          	$newResponse = json_encode($token, 200); 
        }
        return $newResponse;
	}

	public function VerificarUsuario()
	{
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
        $consulta =$objetoAccesoDato->RetornarConsulta("select id, nombre, tipo, estado from usuarios where nombre = :nombreUsuario AND clave = :clave");
        $consulta->bindValue(':nombreUsuario', $this->nombre, PDO::PARAM_STR);
        $consulta->bindValue(':clave', $this->clave, PDO::PARAM_STR);
		$consulta->execute();			
		$employee = $consulta->fetchObject('usuario'); 
        if($employee != NULL)
        {
            $nueva = $employee;
        }
        else
        {
            $nueva = false;
        }
        return $nueva;
	}

	public static function CrearUsuario($request, $response)
	{
		$parametros = $request->getParsedBody();

		if(isset($parametros['nombre']) != null && isset($parametros['clave']) != null && isset($parametros['tipo']) != null && isset($parametros['estado']) != null)
		{
			$employee = new Usuario($parametros['nombre'], $parametros['clave'], $parametros['tipo'], $parametros['estado']);
			if (usuarioPDO::InsertarUsuarioBD($employee) != null) {
				$retorno = $response->withJson("Usuario creado", 200);
			}
			else
			{
	        	throw new Exception("Error al insertar en base de datos", 500);
			}
		}	
		else
		{
			$nueva = new stdclass();
	       	$nueva->respuesta = "Parametros incorrectos o faltantes";
	        $retorno = $response->withJson($nueva, 401);
		}
		return $retorno;
	}

	public static function SuspenderUsuario($request, $response, $args)
	{
		$param = $request->getParsedBody();
		$id = $param['id'];
		$respuesta = new stdclass();
		if(usuarioPDO::DarDeBajaUsuario($id) > 0)
		{	
			$respuesta->resultado = "Suspension exitosa";
		}
		else
		{
			throw new Exception("Ocurrio un error", 500);
		}
		$nueva = $response->withJson($respuesta, 200);
		return $nueva;
	}	

	public static function BajaUsuario($request, $response, $args)
	{
		$param = $request->getParsedBody();
		$id = $param['id'];
		$respuesta = new stdclass();
		if(usuarioPDO::BorrarUsuarioBD($id) > 0) 
		{	
			$respuesta->resultado = "Baja exitosa";
		}
		else
		{
			throw new Exception("Ocurrio un error", 500);
		}
		$nueva = $response->withJson($respuesta, 200);
		return $nueva;
	}	

	public static function ModificarUsuario($request, $response, $args)
	{
		$param = $request->getParsedBody();
		$id = $param['id'];
		if($id != null)
		{
			$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
	        $consulta =$objetoAccesoDato->RetornarConsulta("select * from usuarios where id = :id");
	        $consulta->bindValue(':id', $id, PDO::PARAM_INT);
			$consulta->execute();			
			$employee = $consulta->fetchObject('usuario'); 

			if ($employee != null) {
				if (isset($param['nombre'])) {
					$employee->nombre = $param['nombre'];
				}
				if (isset($param['tipo'])) {
					$employee->tipo = $param['tipo'];	
				}
				if (isset($param['clave'])) {
					$employee->clave = $param['clave'];
				}
				if (isset($param['estado'])) {
					$employee->estado = $param['estado'];
				}
				$respuesta = new stdclass();
				if(usuarioPDO::ModificarUsuarioBD($employee))
				{
					$respuesta->resultado = "Usuario modificado correctamente";
					$nueva = $response->withJson($respuesta, 200);
				}
				else
				{
					throw new Exception("Error al insertar en base de datos", 500);
				}
			}
			else
			{
				$nueva = new stdclass();
	        	$nueva->respuesta = "No existe el usuario";
	        	$nueva = $response->withJson($nueva, 200);
			}
		}
		else
		{
			$nueva = new stdclass();
	       	$nueva->respuesta = "Se necesita un id";
	        $nueva = $response->withJson($nueva, 200);
		}
		return $nueva;
	}



}


?>