// var personas = [{"id":1,"first_name":"Doralyn","last_name":"Sacchetti","email":"dsacchetti0@mysql.com","gender":"Female"},
// {"id":2,"first_name":"Elene","last_name":"Parade","email":"eparade1@cnet.com","gender":"Female"},
// {"id":3,"first_name":"Marlin","last_name":"Po","email":"mpo2@yellowpages.com","gender":"Male"},
// {"id":4,"first_name":"Waneta","last_name":"Schowenburg","email":"wschowenburg3@netscape.com","gender":"Female"},
// {"id":5,"first_name":"Daryl","last_name":"Hess","email":"dhess4@nymag.com","gender":"Male"},
// {"id":6,"first_name":"Antoine","last_name":"Wabersich","email":"awabersich5@bloglines.com","gender":"Male"},
// {"id":7,"first_name":"Michaella","last_name":"Woolager","email":"mwoolager6@creativecommons.org","gender":"Female"},
// {"id":8,"first_name":"Meredeth","last_name":"Mouser","email":"mmouser7@surveymonkey.com","gender":"Male"},
// {"id":9,"first_name":"Cole","last_name":"Leggett","email":"cleggett8@walmart.com","gender":"Male"},
// {"id":10,"first_name":"Joyce","last_name":"Cropp","email":"jcropp9@stumbleupon.com","gender":"Female"}];

var personas = [{"legajo":2120,"nombre":"juan","sexo":"m"},{"legajo":2121,"nombre":"pedro","sexo":"m","dni":"39.111.111"}]