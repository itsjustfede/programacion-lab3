window.addEventListener('load', inicializarEventos);

function inicializarEventos(){
    document.getElementById('btnTabla').addEventListener('click', cargarTabla);
}

function cargarTabla(){
    console.log(personas);

    // var h1 = document.createElement('h1');

    // var texto = document.createTextNode("Fede");

    // h1.appendChild(texto);

    // document.getElementById('info').appendChild(h1);

    var tabla = document.createElement('table');

    // tabla.setAttribute('class','tabla');
    // tabla.className = 'tabla';

    tabla.setAttribute('border', '1px solid black');
    tabla.setAttribute('style', 'border-collapse:collapse');
    tabla.setAttribute('width', '700px');

    var cabecera = document.createElement('tr');

    for(var atributo in personas[0]){
        var th = document.createElement('th');
        var texto = document.createTextNode(atributo);
        th.appendChild(texto);
        cabecera.appendChild(th);
    }
    
    tabla.appendChild(cabecera);

    for(var i in personas){
        var fila = document.createElement('tr');
        for (var j in personas[i]){
            var celda = document.createElement('td');
            celda.setAttribute('style', 'text-align:center');
            var dato = document.createTextNode(personas[i][j]);
            celda.appendChild(dato);
            fila.appendChild(celda);
        }
        tabla.appendChild(fila);
    }
    document.getElementById('info').appendChild(tabla);
}