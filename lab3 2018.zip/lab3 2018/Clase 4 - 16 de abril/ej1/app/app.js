//manejadores de eventos
/*
document.getElementById("p1").onclick = function(){
    this.innerHTML="jkjkjkjkjkj";
};
*/
window.addEventListener("load", inicializarEventos);

function inicializarEventos(){
    document.getElementById("p1").addEventListener("click", function(){
    this.innerHTML="jkjkjkj";
    });
}




function saludar(){
    //document.write("Hola mundo");
    console.log("Hola mundo");
    //window.alert("Hola mundo");

    document.getElementById("p1").innerHTML = "ke onda ke pex";

    function x(a,b,c){
        // console.log(arguments.length); //arguments es el array de parametros
        // for (var i = 0; i < arguments.length; i++) {
        //     console.log(arguments[i]);
        // }
        if(a && b){
            return a+b;
        }
    }

    console.log(x(3,5));
}